#pragma once

#include "test_runner.h"

#ifdef LOCAL_TEST

void
run_tests();

#endif